from setuptools import setup
from setuptools import find_packages

setup(name='my_package_21CS30042',
version='1.0',
description='Python assignment',
author='Ritesah',
author_email='ritesahmadhunala@gmail.com',
packages=find_packages()
)